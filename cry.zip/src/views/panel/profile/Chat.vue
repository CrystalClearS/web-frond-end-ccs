<template>

</template>

<script>
    export default {
        name: "Chat"
    }
</script>

<style scoped>

</style>
