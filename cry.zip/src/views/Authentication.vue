<template>

</template>

<script>
  export default {
    name: 'Authentication'
  }
</script>

<style scoped>

</style>
